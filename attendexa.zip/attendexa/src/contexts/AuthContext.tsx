import React, { createContext, useContext, useState, useCallback, useEffect } from "react";

export type UserRole = "admin" | "instructor" | "student";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  studentId?: string;
  deviceId?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, otp: string) => Promise<boolean>;
  sendOtp: (email: string) => Promise<{ success: boolean; role?: UserRole }>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const UNIVERSITY_DOMAIN = "university.edu";
const INACTIVITY_TIMEOUT = 15 * 60 * 1000; // 15 minutes

// Mock users for demo
const MOCK_USERS: Record<string, Omit<User, "deviceId">> = {
  "admin@university.edu": { id: "1", email: "admin@university.edu", name: "Dr. Sarah Mitchell", role: "admin" },
  "instructor@university.edu": { id: "2", email: "instructor@university.edu", name: "Prof. James Anderson", role: "instructor" },
  "student@university.edu": { id: "3", email: "student@university.edu", name: "Ahmed Al-Rashid", role: "student", studentId: "STU-2024-001" },
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const stored = sessionStorage.getItem("attendexa_user");
    return stored ? JSON.parse(stored) : null;
  });
  const [isLoading, setIsLoading] = useState(false);

  // Inactivity auto-logout
  useEffect(() => {
    if (!user) return;
    let timeout: ReturnType<typeof setTimeout>;
    const resetTimer = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        setUser(null);
        sessionStorage.removeItem("attendexa_user");
      }, INACTIVITY_TIMEOUT);
    };
    const events = ["mousedown", "keydown", "scroll", "touchstart"];
    events.forEach((e) => window.addEventListener(e, resetTimer));
    resetTimer();
    return () => {
      clearTimeout(timeout);
      events.forEach((e) => window.removeEventListener(e, resetTimer));
    };
  }, [user]);

  const sendOtp = useCallback(async (email: string): Promise<{ success: boolean; role?: UserRole }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setIsLoading(false);

    if (!email.endsWith(`@${UNIVERSITY_DOMAIN}`)) {
      return { success: false };
    }
    const mockUser = MOCK_USERS[email];
    if (mockUser) {
      return { success: true, role: mockUser.role };
    }
    return { success: false };
  }, []);

  const login = useCallback(async (email: string, _otp: string): Promise<boolean> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    setIsLoading(false);

    const mockUser = MOCK_USERS[email];
    if (mockUser) {
      const deviceId = navigator.userAgent.slice(0, 50);
      const fullUser: User = { ...mockUser, deviceId };
      setUser(fullUser);
      sessionStorage.setItem("attendexa_user", JSON.stringify(fullUser));
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    sessionStorage.removeItem("attendexa_user");
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, sendOtp, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
