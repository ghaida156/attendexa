import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import AppLayout from "@/components/layout/AppLayout";
import Login from "@/pages/Login";
import StudentDashboard from "@/pages/student/StudentDashboard";
import StudentSchedule from "@/pages/student/StudentSchedule";
import StudentCourses from "@/pages/student/StudentCourses";
import StudentAttendance from "@/pages/student/StudentAttendance";
import InstructorDashboard from "@/pages/instructor/InstructorDashboard";
import InstructorSessions from "@/pages/instructor/InstructorSessions";
import InstructorAttendance from "@/pages/instructor/InstructorAttendance";
import InstructorExport from "@/pages/instructor/InstructorExport";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminUsers from "@/pages/admin/AdminUsers";
import AdminRooms from "@/pages/admin/AdminRooms";
import AdminReports from "@/pages/admin/AdminReports";
import AdminAnalytics from "@/pages/admin/AdminAnalytics";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

function ProtectedRoute({ children, allowedRoles }: { children: React.ReactNode; allowedRoles?: string[] }) {
  const { user, isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return <Navigate to={`/${user.role}`} replace />;
  }
  return <>{children}</>;
}

function RootRedirect() {
  const { user, isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <Navigate to={`/${user!.role}`} replace />;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />
      <Route path="/login" element={<Login />} />

      {/* Student */}
      <Route element={<ProtectedRoute allowedRoles={["student"]}><AppLayout /></ProtectedRoute>}>
        <Route path="/student" element={<StudentDashboard />} />
        <Route path="/student/schedule" element={<StudentSchedule />} />
        <Route path="/student/courses" element={<StudentCourses />} />
        <Route path="/student/attendance" element={<StudentAttendance />} />
      </Route>

      {/* Instructor */}
      <Route element={<ProtectedRoute allowedRoles={["instructor"]}><AppLayout /></ProtectedRoute>}>
        <Route path="/instructor" element={<InstructorDashboard />} />
        <Route path="/instructor/sessions" element={<InstructorSessions />} />
        <Route path="/instructor/attendance" element={<InstructorAttendance />} />
        <Route path="/instructor/export" element={<InstructorExport />} />
      </Route>

      {/* Admin */}
      <Route element={<ProtectedRoute allowedRoles={["admin"]}><AppLayout /></ProtectedRoute>}>
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/admin/rooms" element={<AdminRooms />} />
        <Route path="/admin/reports" element={<AdminReports />} />
        <Route path="/admin/analytics" element={<AdminAnalytics />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
