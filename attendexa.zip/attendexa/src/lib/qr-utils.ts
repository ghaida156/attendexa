// QR code generation utilities for attendance sessions
import CryptoJS from "crypto-js";

export interface QRPayload {
  sessionId: string;
  courseCode: string;
  room: string;
  timestamp: number;
  nonce: string;
  expiresAt: number;
}

const QR_SECRET = "attendexa-qr-secret-2024"; // In production, this would be server-side
const QR_REFRESH_INTERVAL = 10; // seconds

// Generate a unique nonce
function generateNonce(): string {
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

// Create a signed QR payload
export function generateQRPayload(sessionId: string, courseCode: string, room: string): QRPayload {
  const now = Date.now();
  const payload: QRPayload = {
    sessionId,
    courseCode,
    room,
    timestamp: now,
    nonce: generateNonce(),
    expiresAt: now + QR_REFRESH_INTERVAL * 1000,
  };
  return payload;
}

// Encode payload to a compact string for QR
export function encodeQRData(payload: QRPayload): string {
  const json = JSON.stringify(payload);
  const encrypted = CryptoJS.AES.encrypt(json, QR_SECRET).toString();
  return encrypted;
}

// Decode QR data back to payload
export function decodeQRData(data: string): QRPayload | null {
  try {
    const bytes = CryptoJS.AES.decrypt(data, QR_SECRET);
    const json = bytes.toString(CryptoJS.enc.Utf8);
    if (!json) return null;
    return JSON.parse(json) as QRPayload;
  } catch {
    return null;
  }
}

// Validate a scanned QR payload
export function validateQRPayload(payload: QRPayload): { valid: boolean; reason?: string } {
  const now = Date.now();
  if (now > payload.expiresAt) {
    return { valid: false, reason: "QR code has expired" };
  }
  if (!payload.sessionId || !payload.courseCode || !payload.room) {
    return { valid: false, reason: "Invalid QR data" };
  }
  return { valid: true };
}

export { QR_REFRESH_INTERVAL };
