// Geofencing utility for campus attendance verification

export interface GeoCoords {
  lat: number;
  lng: number;
}

export interface GeofenceResult {
  isWithinRange: boolean;
  distance: number; // meters
  roomName: string;
}

// Room coordinates (would come from admin config in production)
export const CAMPUS_ROOMS: Record<string, GeoCoords & { radius: number }> = {
  "A-105": { lat: 24.7136, lng: 46.6753, radius: 50 },
  "B-201": { lat: 24.7140, lng: 46.6758, radius: 50 },
  "C-302": { lat: 24.7145, lng: 46.6762, radius: 50 },
  "D-110": { lat: 24.7150, lng: 46.6770, radius: 50 },
};

// Haversine formula to calculate distance between two GPS coordinates
export function calculateDistance(coord1: GeoCoords, coord2: GeoCoords): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = (coord1.lat * Math.PI) / 180;
  const φ2 = (coord2.lat * Math.PI) / 180;
  const Δφ = ((coord2.lat - coord1.lat) * Math.PI) / 180;
  const Δλ = ((coord2.lng - coord1.lng) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export function checkGeofence(userCoords: GeoCoords, roomName: string): GeofenceResult {
  const room = CAMPUS_ROOMS[roomName];
  if (!room) {
    return { isWithinRange: false, distance: -1, roomName };
  }
  const distance = calculateDistance(userCoords, { lat: room.lat, lng: room.lng });
  return {
    isWithinRange: distance <= room.radius,
    distance: Math.round(distance),
    roomName,
  };
}

export function getCurrentPosition(): Promise<GeoCoords> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  });
}
