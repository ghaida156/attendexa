// Mock SIS (Student Information System) integration
// In production, this would connect to the university's SIS API

export interface SISStudent {
  id: string;
  studentId: string;
  name: string;
  email: string;
  major: string;
  gpa: number;
  enrollmentYear: number;
  status: "active" | "probation" | "suspended";
}

export interface SISCourse {
  code: string;
  name: string;
  section: string;
  creditHours: number;
  instructorId: string;
  instructorName: string;
  semester: string;
  maxAbsencePercent: number;
  schedule: { day: string; startTime: string; endTime: string; room: string }[];
  enrolledStudents: string[];
}

export interface SISAttendanceRecord {
  studentId: string;
  courseCode: string;
  date: string;
  status: "present" | "late" | "absent";
  checkInTime?: string;
  method: "qr" | "manual" | "auto";
}

// Mock SIS Students
export const SIS_STUDENTS: SISStudent[] = [
  { id: "3", studentId: "STU-2024-001", name: "Ahmed Al-Rashid", email: "student@university.edu", major: "Computer Science", gpa: 3.45, enrollmentYear: 2022, status: "active" },
  { id: "s2", studentId: "STU-2024-002", name: "Fatima Hassan", email: "fatima@university.edu", major: "Computer Science", gpa: 3.78, enrollmentYear: 2022, status: "active" },
  { id: "s3", studentId: "STU-2024-003", name: "Omar Khaled", email: "omar@university.edu", major: "Information Systems", gpa: 2.95, enrollmentYear: 2023, status: "active" },
  { id: "s4", studentId: "STU-2024-004", name: "Layla Ibrahim", email: "layla@university.edu", major: "Computer Science", gpa: 3.12, enrollmentYear: 2022, status: "probation" },
  { id: "s5", studentId: "STU-2024-005", name: "Yusuf Nasser", email: "yusuf@university.edu", major: "Software Engineering", gpa: 3.60, enrollmentYear: 2023, status: "active" },
  { id: "s6", studentId: "STU-2024-006", name: "Sara Al-Farsi", email: "sara@university.edu", major: "Computer Science", gpa: 3.88, enrollmentYear: 2021, status: "active" },
  { id: "s7", studentId: "STU-2024-007", name: "Khalid Mansour", email: "khalid@university.edu", major: "Data Science", gpa: 2.70, enrollmentYear: 2023, status: "probation" },
  { id: "s8", studentId: "STU-2024-008", name: "Nora Al-Qahtani", email: "nora@university.edu", major: "Computer Science", gpa: 3.55, enrollmentYear: 2022, status: "active" },
];

// Mock SIS Courses
export const SIS_COURSES: SISCourse[] = [
  {
    code: "CS301", name: "Data Structures", section: "A", creditHours: 3,
    instructorId: "2", instructorName: "Prof. James Anderson", semester: "Spring 2024",
    maxAbsencePercent: 25,
    schedule: [
      { day: "Sunday", startTime: "09:00", endTime: "10:30", room: "B-201" },
      { day: "Tuesday", startTime: "13:00", endTime: "14:30", room: "B-201" },
    ],
    enrolledStudents: ["STU-2024-001", "STU-2024-002", "STU-2024-003", "STU-2024-004", "STU-2024-005", "STU-2024-006"],
  },
  {
    code: "CS405", name: "Machine Learning", section: "A", creditHours: 3,
    instructorId: "2", instructorName: "Prof. James Anderson", semester: "Spring 2024",
    maxAbsencePercent: 25,
    schedule: [
      { day: "Monday", startTime: "11:00", endTime: "12:30", room: "A-105" },
      { day: "Thursday", startTime: "09:00", endTime: "10:30", room: "A-105" },
    ],
    enrolledStudents: ["STU-2024-001", "STU-2024-002", "STU-2024-005", "STU-2024-007", "STU-2024-008"],
  },
  {
    code: "MATH201", name: "Linear Algebra", section: "B", creditHours: 3,
    instructorId: "inst2", instructorName: "Dr. Amira Saleh", semester: "Spring 2024",
    maxAbsencePercent: 25,
    schedule: [
      { day: "Sunday", startTime: "11:00", endTime: "12:30", room: "C-302" },
      { day: "Tuesday", startTime: "08:00", endTime: "09:30", room: "C-302" },
    ],
    enrolledStudents: ["STU-2024-001", "STU-2024-003", "STU-2024-004", "STU-2024-006", "STU-2024-008"],
  },
  {
    code: "ENG102", name: "Technical Writing", section: "A", creditHours: 2,
    instructorId: "inst3", instructorName: "Prof. David Clark", semester: "Spring 2024",
    maxAbsencePercent: 25,
    schedule: [
      { day: "Wednesday", startTime: "13:00", endTime: "14:30", room: "D-110" },
      { day: "Thursday", startTime: "11:00", endTime: "12:30", room: "D-110" },
    ],
    enrolledStudents: ["STU-2024-001", "STU-2024-002", "STU-2024-004", "STU-2024-007"],
  },
];

// Mock attendance history
export const SIS_ATTENDANCE_HISTORY: SISAttendanceRecord[] = [
  { studentId: "STU-2024-001", courseCode: "CS301", date: "2024-04-01", status: "present", checkInTime: "09:02", method: "qr" },
  { studentId: "STU-2024-001", courseCode: "CS301", date: "2024-04-03", status: "absent", method: "auto" },
  { studentId: "STU-2024-001", courseCode: "CS301", date: "2024-04-07", status: "present", checkInTime: "09:01", method: "qr" },
  { studentId: "STU-2024-001", courseCode: "CS301", date: "2024-04-10", status: "late", checkInTime: "09:22", method: "qr" },
  { studentId: "STU-2024-001", courseCode: "CS405", date: "2024-04-01", status: "present", checkInTime: "11:03", method: "qr" },
  { studentId: "STU-2024-001", courseCode: "CS405", date: "2024-04-04", status: "absent", method: "auto" },
  { studentId: "STU-2024-001", courseCode: "MATH201", date: "2024-04-02", status: "absent", method: "auto" },
  { studentId: "STU-2024-001", courseCode: "MATH201", date: "2024-04-07", status: "late", checkInTime: "11:18", method: "qr" },
  { studentId: "STU-2024-001", courseCode: "MATH201", date: "2024-04-09", status: "absent", method: "auto" },
  { studentId: "STU-2024-001", courseCode: "MATH201", date: "2024-04-14", status: "absent", method: "auto" },
  { studentId: "STU-2024-001", courseCode: "MATH201", date: "2024-04-16", status: "absent", method: "auto" },
  { studentId: "STU-2024-001", courseCode: "ENG102", date: "2024-04-03", status: "present", checkInTime: "13:01", method: "qr" },
  { studentId: "STU-2024-001", courseCode: "ENG102", date: "2024-04-04", status: "present", checkInTime: "11:02", method: "qr" },
];

// SIS API simulation functions
export function getStudentByEmail(email: string): SISStudent | undefined {
  return SIS_STUDENTS.find((s) => s.email === email);
}

export function getStudentById(studentId: string): SISStudent | undefined {
  return SIS_STUDENTS.find((s) => s.studentId === studentId);
}

export function getCoursesForStudent(studentId: string): SISCourse[] {
  return SIS_COURSES.filter((c) => c.enrolledStudents.includes(studentId));
}

export function getCoursesForInstructor(instructorId: string): SISCourse[] {
  return SIS_COURSES.filter((c) => c.instructorId === instructorId);
}

export function getAttendanceForStudent(studentId: string, courseCode?: string): SISAttendanceRecord[] {
  return SIS_ATTENDANCE_HISTORY.filter(
    (r) => r.studentId === studentId && (!courseCode || r.courseCode === courseCode)
  );
}

export function getStudentsInCourse(courseCode: string): SISStudent[] {
  const course = SIS_COURSES.find((c) => c.code === courseCode);
  if (!course) return [];
  return SIS_STUDENTS.filter((s) => course.enrolledStudents.includes(s.studentId));
}

// Calculate absence percentage for a student in a course
export function calculateAbsencePercentage(studentId: string, courseCode: string, totalClasses: number): number {
  const records = getAttendanceForStudent(studentId, courseCode);
  const absences = records.filter((r) => r.status === "absent").length;
  const lates = records.filter((r) => r.status === "late").length;
  // 3 lates = 1 absence
  const effectiveAbsences = absences + Math.floor(lates / 3);
  return totalClasses > 0 ? Math.round((effectiveAbsences / totalClasses) * 100) : 0;
}
