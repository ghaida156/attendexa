import { useAuth } from "@/contexts/AuthContext";
import { NavLink, useNavigate, Outlet } from "react-router-dom";
import attendexaLogo from "@/assets/attendexa-logo.png";
import {
  LayoutDashboard,
  Users,
  MapPin,
  FileText,
  Brain,
  CalendarDays,
  BookOpen,
  ClipboardCheck,
  LogOut,
  Shield,
  GraduationCap,
  Menu,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const navItems = {
  admin: [
    { to: "/admin", icon: LayoutDashboard, label: "Dashboard" },
    { to: "/admin/users", icon: Users, label: "User Management" },
    { to: "/admin/rooms", icon: MapPin, label: "Rooms & Locations" },
    { to: "/admin/reports", icon: FileText, label: "Reports" },
    { to: "/admin/analytics", icon: Brain, label: "AI Analytics" },
  ],
  instructor: [
    { to: "/instructor", icon: LayoutDashboard, label: "Dashboard" },
    { to: "/instructor/sessions", icon: ClipboardCheck, label: "Sessions" },
    { to: "/instructor/attendance", icon: CalendarDays, label: "Attendance" },
    { to: "/instructor/export", icon: FileText, label: "Export Data" },
  ],
  student: [
    { to: "/student", icon: LayoutDashboard, label: "Dashboard" },
    { to: "/student/schedule", icon: CalendarDays, label: "Schedule" },
    { to: "/student/courses", icon: BookOpen, label: "My Courses" },
    { to: "/student/attendance", icon: ClipboardCheck, label: "Attendance" },
  ],
};

const roleIcons = {
  admin: Shield,
  instructor: GraduationCap,
  student: BookOpen,
};

export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!user) return null;

  const items = navItems[user.role];
  const RoleIcon = roleIcons[user.role];

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-foreground/20 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 lg:static lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
          <img src={attendexaLogo} alt="Attendexa" width={48} height={48} className="h-12 w-12 rounded-lg -ml-1" />
          <div>
            <h1 className="text-base font-bold tracking-tight">Attendexa</h1>
            <p className="text-xs text-sidebar-foreground/60 capitalize">{user.role} Portal</p>
          </div>
          <button className="ml-auto lg:hidden" onClick={() => setSidebarOpen(false)}>
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4 overflow-y-auto">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === `/${user.role}`}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                }`
              }
            >
              <item.icon className="h-4 w-4 flex-shrink-0" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-sidebar-border p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-accent">
              <RoleIcon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-sidebar-foreground/60 truncate">{user.email}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center gap-4 border-b border-border bg-card px-6 py-3 lg:hidden">
          <button onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5" />
          </button>
          <span className="text-sm font-semibold">Attendexa</span>
        </header>
        <div className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
