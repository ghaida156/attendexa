import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, KeyRound, AlertCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import attendexaLogo from "@/assets/attendexa-logo.png";

const UNIVERSITY_DOMAIN = "university.edu";

export default function Login() {
  const { sendOtp, login, isLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [detectedRole, setDetectedRole] = useState("");

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email.endsWith(`@${UNIVERSITY_DOMAIN}`)) {
      setError(`Only @${UNIVERSITY_DOMAIN} emails are accepted.`);
      return;
    }

    const result = await sendOtp(email);
    if (result.success) {
      setDetectedRole(result.role || "");
      setStep("otp");
      toast({
        title: "Verification Code Sent",
        description: `A 6-digit code has been sent to ${email}`,
      });
    } else {
      setError("Account not found. Please contact your administrator.");
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (otp.length !== 6) {
      setError("Please enter the 6-digit verification code.");
      return;
    }

    const success = await login(email, otp);
    if (success) {
      toast({ title: "Welcome to Attendexa", description: "You have been signed in successfully." });
      const routes: Record<string, string> = { admin: "/admin", instructor: "/instructor", student: "/student" };
      navigate(routes[detectedRole] || "/student");
    } else {
      setError("Invalid verification code. Please try again.");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="mb-6 text-center">
          <img src={attendexaLogo} alt="Attendexa Logo" width={180} height={180} className="mx-auto h-[180px] w-[180px]" />
          <p className="text-sm text-muted-foreground">University Attendance Management System</p>
        </div>

        <Card className="border-border shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-lg">
              {step === "email" ? "Sign In" : "Verify Identity"}
            </CardTitle>
            <CardDescription>
              {step === "email"
                ? "Enter your university email to continue"
                : `Enter the code sent to ${email}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === "email" ? (
              <form onSubmit={handleSendOtp} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">University Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder={`name@${UNIVERSITY_DOMAIN}`}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <div className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Send Verification Code
                </Button>

                <div className="text-center">
                  <p className="text-xs text-muted-foreground">
                    Demo accounts: admin@ / instructor@ / student@{UNIVERSITY_DOMAIN}
                  </p>
                </div>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-4">
                {detectedRole && (
                  <div className="rounded-lg bg-accent/10 px-3 py-2 text-center text-sm">
                    Detected role: <span className="font-semibold capitalize text-accent">{detectedRole}</span>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="otp">Verification Code</Label>
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="otp"
                      type="text"
                      placeholder="000000"
                      maxLength={6}
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                      className="pl-10 text-center text-lg tracking-[0.3em]"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <div className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Verify & Sign In
                </Button>

                <Button type="button" variant="ghost" className="w-full" onClick={() => { setStep("email"); setOtp(""); setError(""); }}>
                  Use a different email
                </Button>
              </form>
            )}
          </CardContent>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Protected by AES-256 encryption · TLS secured · Device-bound sessions
        </p>
      </div>
    </div>
  );
}
