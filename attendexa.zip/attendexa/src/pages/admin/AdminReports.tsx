import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, FileSpreadsheet, Download, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const reportTypes = [
  { name: "Attendance Summary", desc: "Overall attendance rates by course and section", icon: FileText },
  { name: "At-Risk Students", desc: "Students exceeding 25% absence threshold", icon: FileText },
  { name: "Instructor Report", desc: "Session history and attendance per instructor", icon: FileSpreadsheet },
  { name: "Monthly Breakdown", desc: "Day-by-day attendance patterns", icon: Calendar },
];

export default function AdminReports() {
  const { toast } = useToast();

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Reports</h2>
        <p className="text-muted-foreground">Generate and export attendance reports</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {reportTypes.map((r) => (
          <Card key={r.name} className="transition-shadow hover:shadow-md">
            <CardContent className="flex items-center gap-4 py-6">
              <div className="rounded-lg bg-accent/10 p-3"><r.icon className="h-5 w-5 text-accent" /></div>
              <div className="flex-1">
                <p className="font-semibold">{r.name}</p>
                <p className="text-sm text-muted-foreground">{r.desc}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => toast({ title: "PDF exported (demo)" })}>
                  <Download className="mr-1 h-3 w-3" />PDF
                </Button>
                <Button variant="outline" size="sm" onClick={() => toast({ title: "Excel exported (demo)" })}>
                  <Download className="mr-1 h-3 w-3" />Excel
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
