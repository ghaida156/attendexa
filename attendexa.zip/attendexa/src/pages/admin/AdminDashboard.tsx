import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { Users, MapPin, AlertTriangle, Brain, TrendingUp, ShieldAlert } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();

  const stats = [
    { label: "Total Users", value: "1,248", icon: Users, color: "text-accent", bg: "bg-accent/10" },
    { label: "Active Rooms", value: "42", icon: MapPin, color: "text-success", bg: "bg-success/10" },
    { label: "At-Risk Students", value: "23", icon: AlertTriangle, color: "text-destructive", bg: "bg-destructive/10" },
    { label: "Fraud Alerts", value: "7", icon: ShieldAlert, color: "text-warning", bg: "bg-warning/10" },
    { label: "Avg. Attendance", value: "84%", icon: TrendingUp, color: "text-accent", bg: "bg-accent/10" },
    { label: "AI Insights", value: "12", icon: Brain, color: "text-accent", bg: "bg-accent/10" },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Admin Dashboard</h2>
        <p className="text-muted-foreground">Welcome, {user?.name} — system overview</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label} className="transition-shadow hover:shadow-md">
            <CardContent className="flex items-center gap-4 pt-6">
              <div className={`rounded-xl p-3 ${s.bg}`}><s.icon className={`h-5 w-5 ${s.color}`} /></div>
              <div>
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-2xl font-bold">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
