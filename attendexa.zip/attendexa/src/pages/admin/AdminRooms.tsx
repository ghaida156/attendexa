import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const rooms = [
  { id: "1", name: "A-105", building: "Building A", floor: "1st", capacity: 40, lat: 24.7136, lng: 46.6753 },
  { id: "2", name: "B-201", building: "Building B", floor: "2nd", capacity: 35, lat: 24.7140, lng: 46.6758 },
  { id: "3", name: "C-302", building: "Building C", floor: "3rd", capacity: 50, lat: 24.7145, lng: 46.6762 },
  { id: "4", name: "D-110", building: "Building D", floor: "1st", capacity: 30, lat: 24.7150, lng: 46.6770 },
];

export default function AdminRooms() {
  const { toast } = useToast();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Rooms & Locations</h2>
          <p className="text-muted-foreground">Manage classroom GPS coordinates for geofencing</p>
        </div>
        <Button onClick={() => toast({ title: "Demo", description: "Add room form would open here" })}>
          <Plus className="mr-2 h-4 w-4" />Add Room
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {rooms.map((room) => (
          <Card key={room.id} className="transition-shadow hover:shadow-md">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-accent/10 p-2"><MapPin className="h-4 w-4 text-accent" /></div>
                  <div>
                    <p className="font-semibold">{room.name}</p>
                    <p className="text-sm text-muted-foreground">{room.building} · {room.floor} Floor</p>
                  </div>
                </div>
                <Badge variant="secondary">Cap: {room.capacity}</Badge>
              </div>
              <div className="rounded-lg bg-secondary/50 px-3 py-2 text-xs font-mono text-muted-foreground">
                GPS: {room.lat.toFixed(4)}, {room.lng.toFixed(4)}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
