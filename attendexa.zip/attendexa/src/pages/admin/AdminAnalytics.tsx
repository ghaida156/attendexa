import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingDown, Clock, BookOpen, ShieldAlert, Video, MapPin, AlertTriangle } from "lucide-react";

const insights = [
  { title: "Peak Absence Times", desc: "Sunday 8:00 AM classes have 34% higher absence rates", icon: Clock, type: "pattern" },
  { title: "High-Absence Courses", desc: "MATH201 (Linear Algebra) leads with 28% average absence", icon: BookOpen, type: "pattern" },
  { title: "At-Risk Students", desc: "23 students have exceeded the 25% absence threshold", icon: TrendingDown, type: "alert" },
];

const fraudAlerts = [
  { id: "1", type: "Video detected", student: "Unknown", course: "CS301", time: "Apr 14, 09:15", severity: "high" },
  { id: "2", type: "Location mismatch", student: "Omar K.", course: "MATH201", time: "Apr 13, 08:05", severity: "medium" },
  { id: "3", type: "Duplicate scan attempt", student: "Yusuf N.", course: "CS405", time: "Apr 12, 11:22", severity: "low" },
];

const severityColors: Record<string, string> = {
  high: "text-destructive bg-destructive/10",
  medium: "text-warning bg-warning/10",
  low: "text-muted-foreground bg-muted",
};

export default function AdminAnalytics() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">AI Analytics</h2>
        <p className="text-muted-foreground">Intelligent insights and fraud detection</p>
      </div>

      {/* Insights */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Brain className="h-5 w-5 text-accent" />
          <h3 className="text-lg font-semibold">Pattern Analysis</h3>
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          {insights.map((i) => (
            <Card key={i.title} className="transition-shadow hover:shadow-md">
              <CardContent className="pt-5">
                <div className="flex items-center gap-2 mb-2">
                  <i.icon className="h-4 w-4 text-accent" />
                  <Badge variant={i.type === "alert" ? "destructive" : "secondary"} className="text-xs">{i.type}</Badge>
                </div>
                <p className="font-semibold text-sm">{i.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{i.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Anti-fraud */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <ShieldAlert className="h-5 w-5 text-warning" />
          <h3 className="text-lg font-semibold">Anti-Fraud Alerts</h3>
        </div>
        <div className="space-y-3">
          {fraudAlerts.map((a) => (
            <Card key={a.id}>
              <CardContent className="flex items-center justify-between py-4">
                <div className="flex items-center gap-4">
                  <div className={`rounded-lg p-2 ${severityColors[a.severity]}`}>
                    {a.type.includes("Video") ? <Video className="h-4 w-4" /> : a.type.includes("Location") ? <MapPin className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{a.type}</p>
                    <p className="text-xs text-muted-foreground">{a.student} · {a.course} · {a.time}</p>
                  </div>
                </div>
                <Badge className={`${severityColors[a.severity]} border-0 capitalize`}>{a.severity}</Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
