import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const mockUsers = [
  { id: "1", name: "Dr. Sarah Mitchell", email: "admin@university.edu", role: "admin", status: "active" },
  { id: "2", name: "Prof. James Anderson", email: "instructor@university.edu", role: "instructor", status: "active" },
  { id: "3", name: "Ahmed Al-Rashid", email: "student@university.edu", role: "student", status: "active" },
  { id: "4", name: "Fatima Hassan", email: "fatima@university.edu", role: "student", status: "active" },
  { id: "5", name: "Dr. Chen Wei", email: "chen@university.edu", role: "instructor", status: "inactive" },
];

export default function AdminUsers() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const filtered = mockUsers.filter((u) => u.name.toLowerCase().includes(search.toLowerCase()) || u.email.includes(search));

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">User Management</h2>
          <p className="text-muted-foreground">{mockUsers.length} users registered</p>
        </div>
        <Button onClick={() => toast({ title: "Demo", description: "Add user form would open here" })}>
          <Plus className="mr-2 h-4 w-4" />Add User
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((u) => (
                <TableRow key={u.id}>
                  <TableCell className="font-medium">{u.name}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{u.email}</TableCell>
                  <TableCell><Badge variant="secondary" className="capitalize text-xs">{u.role}</Badge></TableCell>
                  <TableCell>
                    <Badge variant={u.status === "active" ? "default" : "secondary"} className="text-xs capitalize">{u.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm"><Pencil className="h-3 w-3" /></Button>
                    <Button variant="ghost" size="sm"><Trash2 className="h-3 w-3 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
