import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, FileSpreadsheet, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const exportOptions = [
  { format: "PDF", icon: FileText, desc: "Formatted attendance report" },
  { format: "Excel", icon: FileSpreadsheet, desc: "Raw data spreadsheet" },
];

export default function InstructorExport() {
  const { toast } = useToast();

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Export Data</h2>
        <p className="text-muted-foreground">Download attendance reports in PDF or Excel format</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {exportOptions.map((opt) => (
          <Card key={opt.format} className="transition-shadow hover:shadow-md">
            <CardContent className="flex items-center gap-4 py-6">
              <div className="rounded-lg bg-accent/10 p-3">
                <opt.icon className="h-6 w-6 text-accent" />
              </div>
              <div className="flex-1">
                <p className="font-semibold">{opt.format} Export</p>
                <p className="text-sm text-muted-foreground">{opt.desc}</p>
              </div>
              <Button variant="outline" onClick={() => toast({ title: `${opt.format} exported`, description: "Demo — file would download in production" })}>
                <Download className="mr-2 h-4 w-4" />Export
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
