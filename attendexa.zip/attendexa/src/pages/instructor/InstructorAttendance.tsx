import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const attendanceRecords = [
  { student: "Ahmed Al-Rashid", id: "STU-001", cs301: "P", cs405: "P", math201: "A", eng102: "P", total: "87%" },
  { student: "Fatima Hassan", id: "STU-002", cs301: "P", cs405: "L", math201: "P", eng102: "P", total: "93%" },
  { student: "Omar Khaled", id: "STU-003", cs301: "L", cs405: "P", math201: "A", eng102: "A", total: "62%" },
  { student: "Layla Ibrahim", id: "STU-004", cs301: "P", cs405: "P", math201: "P", eng102: "P", total: "100%" },
  { student: "Yusuf Nasser", id: "STU-005", cs301: "A", cs405: "P", math201: "P", eng102: "L", total: "81%" },
];

const statusBadge = (s: string) => {
  if (s === "P") return <Badge className="bg-success/10 text-success border-0 text-xs">P</Badge>;
  if (s === "A") return <Badge className="bg-destructive/10 text-destructive border-0 text-xs">A</Badge>;
  return <Badge className="bg-warning/10 text-warning border-0 text-xs">L</Badge>;
};

export default function InstructorAttendance() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Attendance Records</h2>
        <p className="text-muted-foreground">Overview of all student attendance across your courses</p>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>ID</TableHead>
                <TableHead className="text-center">CS301</TableHead>
                <TableHead className="text-center">CS405</TableHead>
                <TableHead className="text-center">MATH201</TableHead>
                <TableHead className="text-center">ENG102</TableHead>
                <TableHead className="text-center">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {attendanceRecords.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.student}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{r.id}</TableCell>
                  <TableCell className="text-center">{statusBadge(r.cs301)}</TableCell>
                  <TableCell className="text-center">{statusBadge(r.cs405)}</TableCell>
                  <TableCell className="text-center">{statusBadge(r.math201)}</TableCell>
                  <TableCell className="text-center">{statusBadge(r.eng102)}</TableCell>
                  <TableCell className="text-center font-semibold">{r.total}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
