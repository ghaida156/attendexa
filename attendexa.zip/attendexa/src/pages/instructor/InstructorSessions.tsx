import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Users, Clock, UserPlus, MapPin, Shield } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { generateQRPayload, encodeQRData, QR_REFRESH_INTERVAL } from "@/lib/qr-utils";
import { CAMPUS_ROOMS } from "@/lib/geofencing";
import { getStudentsInCourse, SIS_COURSES } from "@/lib/sis-data";

const mockRooms = Object.keys(CAMPUS_ROOMS);
const mockCourses = SIS_COURSES.map((c) => `${c.code} — ${c.name}`);

const liveStudents = [
  { id: "1", name: "Ahmed Al-Rashid", status: "present", time: "09:02", method: "QR + GPS" },
  { id: "2", name: "Fatima Hassan", status: "present", time: "09:03", method: "QR + GPS" },
  { id: "3", name: "Omar Khaled", status: "late", time: "09:18", method: "QR" },
  { id: "4", name: "Layla Ibrahim", status: "absent", time: "—", method: "—" },
  { id: "5", name: "Yusuf Nasser", status: "present", time: "09:01", method: "QR + GPS" },
];

export default function InstructorSessions() {
  const { toast } = useToast();
  const [sessionActive, setSessionActive] = useState(false);
  const [course, setCourse] = useState("");
  const [room, setRoom] = useState("");
  const [duration, setDuration] = useState("15");
  const [qrData, setQrData] = useState("");
  const [qrTimer, setQrTimer] = useState(QR_REFRESH_INTERVAL);
  const [sessionTimer, setSessionTimer] = useState(0);
  const [sessionId] = useState(() => `sess-${Date.now()}`);

  const refreshQR = useCallback(() => {
    if (!course || !room) return;
    const courseCode = course.split(" — ")[0];
    const payload = generateQRPayload(sessionId, courseCode, room);
    const encoded = encodeQRData(payload);
    setQrData(encoded);
    setQrTimer(QR_REFRESH_INTERVAL);
  }, [course, room, sessionId]);

  // QR auto-refresh every 10 seconds
  useEffect(() => {
    if (!sessionActive) return;
    refreshQR();
    const interval = setInterval(refreshQR, QR_REFRESH_INTERVAL * 1000);
    return () => clearInterval(interval);
  }, [sessionActive, refreshQR]);

  // QR countdown timer
  useEffect(() => {
    if (!sessionActive) return;
    const interval = setInterval(() => {
      setQrTimer((t) => (t <= 1 ? QR_REFRESH_INTERVAL : t - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionActive]);

  // Session countdown
  useEffect(() => {
    if (!sessionActive) return;
    setSessionTimer(parseInt(duration) * 60);
    const interval = setInterval(() => {
      setSessionTimer((t) => {
        if (t <= 1) {
          setSessionActive(false);
          toast({ title: "Session Ended", description: "Attendance window has closed." });
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionActive, duration, toast]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const createSession = () => {
    if (!course || !room) {
      toast({ title: "Missing fields", description: "Select course and room", variant: "destructive" });
      return;
    }
    setSessionActive(true);
    toast({ title: "Session Created", description: `QR code is now active for ${duration} minutes` });
  };

  const roomCoords = room ? CAMPUS_ROOMS[room] : null;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Sessions</h2>
        <p className="text-muted-foreground">Create and manage attendance sessions</p>
      </div>

      {!sessionActive ? (
        <Card>
          <CardHeader><CardTitle className="text-base">Create New Session</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label>Course</Label>
                <Select value={course} onValueChange={setCourse}>
                  <SelectTrigger><SelectValue placeholder="Select course" /></SelectTrigger>
                  <SelectContent>{mockCourses.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Room</Label>
                <Select value={room} onValueChange={setRoom}>
                  <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                  <SelectContent>{mockRooms.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Duration (min)</Label>
                <Input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} min="5" max="60" />
              </div>
            </div>

            {room && roomCoords && (
              <div className="flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-2 text-xs text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" />
                <span>Geofence: {roomCoords.lat.toFixed(4)}, {roomCoords.lng.toFixed(4)} · Radius: {roomCoords.radius}m</span>
              </div>
            )}

            <Button onClick={createSession}><Plus className="mr-2 h-4 w-4" />Start Session</Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="border-success/30 bg-success/5">
            <CardContent className="flex items-center justify-between py-4">
              <div className="flex items-center gap-3">
                <div className="h-3 w-3 rounded-full bg-success animate-pulse" />
                <div>
                  <p className="font-semibold text-sm">{course}</p>
                  <p className="text-xs text-muted-foreground">Room {room} · Geofenced</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary"><Shield className="mr-1 h-3 w-3" />AES-256</Badge>
                <Badge><Clock className="mr-1 h-3 w-3" />{formatTime(sessionTimer)}</Badge>
                <Button variant="destructive" size="sm" onClick={() => { setSessionActive(false); toast({ title: "Session Ended" }); }}>
                  End Session
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Live QR Code */}
          <Card>
            <CardContent className="flex flex-col items-center py-8">
              <div className="rounded-xl bg-white p-4 shadow-md">
                {qrData ? (
                  <QRCodeSVG
                    value={qrData}
                    size={200}
                    level="H"
                    includeMargin
                    bgColor="#ffffff"
                    fgColor="#0a1628"
                  />
                ) : (
                  <div className="h-[200px] w-[200px] flex items-center justify-center text-muted-foreground">
                    Generating...
                  </div>
                )}
              </div>
              <div className="mt-4 flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
                <span className="text-sm font-medium">QR refreshes in <span className="font-mono text-accent">{qrTimer}s</span></span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">Encrypted with AES-256 · Unique every {QR_REFRESH_INTERVAL}s</p>
            </CardContent>
          </Card>

          {/* Live attendance */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="h-4 w-4" /> Live Attendance
              </CardTitle>
              <Button variant="outline" size="sm"><UserPlus className="mr-2 h-3 w-3" />Manual Check-in</Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {liveStudents.map((s) => (
                  <div key={s.id} className="flex items-center justify-between rounded-lg bg-secondary/50 px-4 py-3">
                    <span className="text-sm font-medium">{s.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground">{s.method}</span>
                      <span className="text-xs text-muted-foreground">{s.time}</span>
                      <Badge variant={s.status === "present" ? "default" : s.status === "late" ? "secondary" : "destructive"} className="capitalize text-xs">
                        {s.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
