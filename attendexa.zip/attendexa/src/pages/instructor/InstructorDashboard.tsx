import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Users, ClipboardCheck, Clock, AlertTriangle, Plus } from "lucide-react";
import { Link } from "react-router-dom";

const recentSessions = [
  { id: "1", course: "CS301 — Data Structures", date: "Apr 14, 2024", present: 28, total: 32, room: "B-201" },
  { id: "2", course: "CS405 — Machine Learning", date: "Apr 13, 2024", present: 25, total: 30, room: "A-105" },
  { id: "3", course: "CS301 — Data Structures", date: "Apr 12, 2024", present: 30, total: 32, room: "B-201" },
];

export default function InstructorDashboard() {
  const { user } = useAuth();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Welcome, {user?.name?.split(" ").slice(-1)[0]}</h2>
          <p className="text-muted-foreground">Manage your sessions and track attendance</p>
        </div>
        <Link to="/instructor/sessions">
          <Button><Plus className="mr-2 h-4 w-4" />New Session</Button>
        </Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Sessions</p>
                <p className="text-3xl font-bold">1</p>
              </div>
              <div className="rounded-full bg-success/10 p-3"><ClipboardCheck className="h-5 w-5 text-success" /></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-3xl font-bold">62</p>
              </div>
              <div className="rounded-full bg-accent/10 p-3"><Users className="h-5 w-5 text-accent" /></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Attendance</p>
                <p className="text-3xl font-bold">87%</p>
              </div>
              <div className="rounded-full bg-warning/10 p-3"><Clock className="h-5 w-5 text-warning" /></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">At-Risk Students</p>
                <p className="text-3xl font-bold text-destructive">5</p>
              </div>
              <div className="rounded-full bg-destructive/10 p-3"><AlertTriangle className="h-5 w-5 text-destructive" /></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-4">Recent Sessions</h3>
        <div className="space-y-3">
          {recentSessions.map((s) => {
            const pct = Math.round((s.present / s.total) * 100);
            return (
              <Card key={s.id} className="transition-shadow hover:shadow-md">
                <CardContent className="flex items-center justify-between py-4">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                      <ClipboardCheck className="h-5 w-5 text-accent" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{s.course}</p>
                      <p className="text-xs text-muted-foreground">{s.date} · {s.room}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={pct >= 90 ? "default" : pct >= 75 ? "secondary" : "destructive"}>
                      {pct}% present
                    </Badge>
                    <span className="text-sm text-muted-foreground">{s.present}/{s.total}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
