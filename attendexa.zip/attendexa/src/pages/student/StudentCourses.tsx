import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const courses = [
  { id: "1", code: "CS301", name: "Data Structures", instructor: "Prof. Anderson", absences: 3, total: 16 },
  { id: "2", code: "CS405", name: "Machine Learning", instructor: "Dr. Chen", absences: 1, total: 14 },
  { id: "3", code: "MATH201", name: "Linear Algebra", instructor: "Prof. Hassan", absences: 5, total: 16 },
  { id: "4", code: "ENG102", name: "Technical Writing", instructor: "Dr. Williams", absences: 0, total: 12 },
];

export default function StudentCourses() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">My Courses</h2>
        <p className="text-muted-foreground">Spring 2024 · {courses.length} courses enrolled</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {courses.map((course) => {
          const pct = Math.round((course.absences / course.total) * 100);
          const isDanger = pct >= 25;
          const isWarning = pct >= 20;
          return (
            <Card key={course.id} className="transition-shadow hover:shadow-md">
              <CardContent className="pt-5 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <Badge variant="secondary">{course.code}</Badge>
                    <h3 className="mt-2 font-semibold">{course.name}</h3>
                    <p className="text-sm text-muted-foreground">{course.instructor}</p>
                  </div>
                  <span className={`text-2xl font-bold ${isDanger ? "text-destructive" : isWarning ? "text-warning" : "text-success"}`}>
                    {pct}%
                  </span>
                </div>
                <Progress value={pct} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{course.absences} absences of {course.total} classes</span>
                  <span>{course.total - course.absences} attended</span>
                </div>
                <Link to="/student/attendance">
                  <Button variant="outline" size="sm" className="w-full">Check In</Button>
                </Link>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
