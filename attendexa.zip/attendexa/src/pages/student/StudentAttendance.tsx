import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Camera, QrCode, CheckCircle2, AlertCircle, Wifi, MapPin, Clock, ShieldAlert, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { checkGeofence, getCurrentPosition, type GeoCoords } from "@/lib/geofencing";
import { QR_REFRESH_INTERVAL } from "@/lib/qr-utils";

type AttendanceStatus = "idle" | "scanning" | "success" | "late" | "already" | "error" | "out-of-range";

export default function StudentAttendance() {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [status, setStatus] = useState<AttendanceStatus>("idle");
  const [cameraActive, setCameraActive] = useState(false);
  const [qrTimer, setQrTimer] = useState(QR_REFRESH_INTERVAL);
  const [sessionOpen] = useState(true);
  const [geoStatus, setGeoStatus] = useState<"checking" | "valid" | "invalid" | "unavailable">("checking");
  const [geoDistance, setGeoDistance] = useState<number | null>(null);
  const [userCoords, setUserCoords] = useState<GeoCoords | null>(null);
  const [networkValid, setNetworkValid] = useState(true);

  // Check geolocation on mount
  useEffect(() => {
    const checkLocation = async () => {
      try {
        const coords = await getCurrentPosition();
        setUserCoords(coords);
        const result = checkGeofence(coords, "B-201"); // Current session room
        setGeoDistance(result.distance);
        setGeoStatus(result.isWithinRange ? "valid" : "invalid");
      } catch {
        // For demo, simulate being on campus
        setGeoStatus("valid");
        setGeoDistance(12);
        setUserCoords({ lat: 24.7141, lng: 46.6759 });
      }
    };
    checkLocation();

    // Simulate network check
    setNetworkValid(navigator.onLine);
    const handleOnline = () => setNetworkValid(true);
    const handleOffline = () => setNetworkValid(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // QR code timer simulation
  useEffect(() => {
    if (!cameraActive) return;
    const interval = setInterval(() => {
      setQrTimer((t) => (t <= 1 ? QR_REFRESH_INTERVAL : t - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [cameraActive]);

  const startCamera = async () => {
    // Check geofence first
    if (geoStatus === "invalid") {
      setStatus("out-of-range");
      toast({
        title: "Location Alert",
        description: `You are ${geoDistance}m from the classroom. Move closer to check in.`,
        variant: "destructive",
      });
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraActive(true);
      setStatus("scanning");
    } catch {
      toast({ title: "Camera Error", description: "Unable to access camera. Please allow camera permissions.", variant: "destructive" });
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const simulateCheckIn = () => {
    stopCamera();
    const outcomes: AttendanceStatus[] = ["success", "late", "already"];
    const result = outcomes[Math.floor(Math.random() * outcomes.length)];
    setStatus(result);

    const messages: Record<string, { title: string; desc: string }> = {
      success: { title: "Attendance Recorded ✓", desc: "Verified via QR + GPS + Network. You have been marked as present." },
      late: { title: "Late Arrival", desc: "You've been marked as late. 3 lates = 1 absence." },
      already: { title: "Already Recorded", desc: "Your attendance was already registered for this session." },
    };

    const msg = messages[result];
    toast({ title: msg.title, description: msg.desc, variant: result === "late" ? "destructive" : "default" });
  };

  const statusDisplay: Record<AttendanceStatus, { icon: React.ReactNode; text: string; color: string }> = {
    idle: { icon: <QrCode className="h-8 w-8" />, text: "Ready to check in", color: "text-muted-foreground" },
    scanning: { icon: <Camera className="h-8 w-8 animate-pulse" />, text: "Scanning QR code...", color: "text-accent" },
    success: { icon: <CheckCircle2 className="h-8 w-8" />, text: "Attendance confirmed!", color: "text-success" },
    late: { icon: <Clock className="h-8 w-8" />, text: "Marked as late", color: "text-warning" },
    already: { icon: <AlertCircle className="h-8 w-8" />, text: "Already recorded", color: "text-accent" },
    error: { icon: <AlertCircle className="h-8 w-8" />, text: "Check-in failed", color: "text-destructive" },
    "out-of-range": { icon: <ShieldAlert className="h-8 w-8" />, text: "Outside classroom range", color: "text-destructive" },
  };

  const current = statusDisplay[status];

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold">Attendance Check-in</h2>
        <p className="text-muted-foreground">Scan the QR code displayed in your classroom</p>
      </div>

      {/* Session status */}
      <Card className={sessionOpen ? "border-success/30 bg-success/5" : "border-destructive/30 bg-destructive/5"}>
        <CardContent className="flex items-center gap-3 py-3">
          <div className={`h-2.5 w-2.5 rounded-full ${sessionOpen ? "bg-success animate-pulse" : "bg-destructive"}`} />
          <span className="text-sm font-medium">{sessionOpen ? "Session is open — CS301 Data Structures (B-201)" : "No active session"}</span>
        </CardContent>
      </Card>

      {/* Camera / Scanner */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative aspect-video rounded-lg bg-foreground/5 overflow-hidden flex items-center justify-center">
            {cameraActive ? (
              <>
                <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="h-48 w-48 border-2 border-accent rounded-2xl" />
                </div>
                <div className="absolute top-3 right-3">
                  <Badge variant="secondary" className="font-mono">QR refreshes in {qrTimer}s</Badge>
                </div>
                <div className="absolute top-3 left-3">
                  <Badge variant="secondary" className="gap-1">
                    <Shield className="h-3 w-3" />AES-256
                  </Badge>
                </div>
              </>
            ) : (
              <div className={`flex flex-col items-center gap-3 ${current.color}`}>
                {current.icon}
                <p className="text-sm font-medium">{current.text}</p>
                {status === "out-of-range" && geoDistance !== null && (
                  <p className="text-xs text-muted-foreground">Distance: {geoDistance}m from classroom</p>
                )}
              </div>
            )}
          </div>

          <div className="mt-4 flex gap-3">
            {!cameraActive && status !== "scanning" ? (
              <Button className="flex-1" onClick={startCamera} disabled={!sessionOpen}>
                <Camera className="mr-2 h-4 w-4" />
                Open Camera & Scan
              </Button>
            ) : cameraActive ? (
              <>
                <Button variant="outline" className="flex-1" onClick={stopCamera}>Cancel</Button>
                <Button className="flex-1" onClick={simulateCheckIn}>Simulate Check-in</Button>
              </>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* Verification checks */}
      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <CardContent className="flex items-center gap-3 py-4">
            <Wifi className={`h-4 w-4 ${networkValid ? "text-success" : "text-destructive"}`} />
            <div>
              <p className="text-sm font-medium">Network</p>
              <p className="text-xs text-muted-foreground">{networkValid ? "University Wi-Fi ✓" : "Offline — queued"}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 py-4">
            <MapPin className={`h-4 w-4 ${geoStatus === "valid" ? "text-success" : geoStatus === "invalid" ? "text-destructive" : "text-warning"}`} />
            <div>
              <p className="text-sm font-medium">Geofence</p>
              <p className="text-xs text-muted-foreground">
                {geoStatus === "valid" && geoDistance !== null
                  ? `${geoDistance}m from room ✓`
                  : geoStatus === "invalid"
                  ? `${geoDistance}m — out of range`
                  : "Checking..."}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 py-4">
            <QrCode className="h-4 w-4 text-accent" />
            <div>
              <p className="text-sm font-medium">QR Code</p>
              <p className="text-xs text-muted-foreground">Refreshes every {QR_REFRESH_INTERVAL}s</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <p className="text-center text-xs text-muted-foreground">
        If you lose connection, your check-in will be saved locally for up to 60 seconds and submitted automatically.
      </p>
    </div>
  );
}
