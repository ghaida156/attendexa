import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/contexts/AuthContext";
import {
  AlertTriangle,
  BookOpen,
  CalendarDays,
  Clock,
  Bell,
} from "lucide-react";
import { Link } from "react-router-dom";

const mockCourses = [
  { id: "1", code: "CS301", name: "Data Structures", absences: 3, total: 16, nextClass: "Sun 09:00", room: "B-201" },
  { id: "2", code: "CS405", name: "Machine Learning", absences: 1, total: 14, nextClass: "Mon 11:00", room: "A-105" },
  { id: "3", code: "MATH201", name: "Linear Algebra", absences: 5, total: 16, nextClass: "Tue 08:00", room: "C-302" },
  { id: "4", code: "ENG102", name: "Technical Writing", absences: 0, total: 12, nextClass: "Wed 13:00", room: "D-110" },
];

const mockNotifications = [
  { id: "1", type: "warning" as const, message: "Linear Algebra: You've reached 31% absence — limit is 25%!", time: "2 hours ago" },
  { id: "2", type: "info" as const, message: "Session is open: CS301 — Data Structures (B-201)", time: "Just now" },
  { id: "3", type: "info" as const, message: "Last chance to attend: CS405 — closes in 5 min", time: "10 min ago" },
];

export default function StudentDashboard() {
  const { user } = useAuth();
  const totalAbsences = mockCourses.reduce((sum, c) => sum + c.absences, 0);
  const totalClasses = mockCourses.reduce((sum, c) => sum + c.total, 0);
  const overallPercentage = Math.round((totalAbsences / totalClasses) * 100);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Welcome back, {user?.name?.split(" ")[0]}</h2>
        <p className="text-muted-foreground">Here's your attendance overview for this semester</p>
      </div>

      {/* Stats row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overall Absence</p>
                <p className={`text-3xl font-bold ${overallPercentage > 20 ? "text-destructive" : "text-success"}`}>
                  {overallPercentage}%
                </p>
              </div>
              <div className={`rounded-full p-3 ${overallPercentage > 20 ? "bg-destructive/10" : "bg-success/10"}`}>
                <AlertTriangle className={`h-5 w-5 ${overallPercentage > 20 ? "text-destructive" : "text-success"}`} />
              </div>
            </div>
            <Progress value={overallPercentage} className="mt-3 h-2" />
            <p className="mt-1 text-xs text-muted-foreground">Limit: 25%</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Enrolled Courses</p>
                <p className="text-3xl font-bold">{mockCourses.length}</p>
              </div>
              <div className="rounded-full bg-accent/10 p-3">
                <BookOpen className="h-5 w-5 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Absences</p>
                <p className="text-3xl font-bold">{totalAbsences}</p>
              </div>
              <div className="rounded-full bg-warning/10 p-3">
                <CalendarDays className="h-5 w-5 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Late Arrivals</p>
                <p className="text-3xl font-bold">2</p>
              </div>
              <div className="rounded-full bg-muted p-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">3 late = 1 absence</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Courses */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">My Courses</h3>
            <Link to="/student/courses">
              <Button variant="ghost" size="sm">View All</Button>
            </Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {mockCourses.map((course) => {
              const pct = Math.round((course.absences / course.total) * 100);
              const isWarning = pct >= 20;
              const isDanger = pct >= 25;
              return (
                <Card key={course.id} className="group transition-shadow hover:shadow-md">
                  <CardContent className="pt-5">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <Badge variant="secondary" className="mb-1 text-xs">{course.code}</Badge>
                        <p className="font-medium text-sm">{course.name}</p>
                      </div>
                      <span className={`text-lg font-bold ${isDanger ? "text-destructive" : isWarning ? "text-warning" : "text-success"}`}>
                        {pct}%
                      </span>
                    </div>
                    <Progress value={pct} className="h-1.5 mb-2" />
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{course.absences}/{course.total} absent</span>
                      <span>{course.nextClass} · {course.room}</span>
                    </div>
                    <Link to="/student/attendance">
                      <Button size="sm" className="mt-3 w-full" variant={isDanger ? "destructive" : "default"}>
                        Check In
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Notifications */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <h3 className="text-lg font-semibold">Notifications</h3>
          </div>
          <div className="space-y-3">
            {mockNotifications.map((n) => (
              <Card key={n.id} className={n.type === "warning" ? "border-destructive/30 bg-destructive/5" : ""}>
                <CardContent className="py-3 px-4">
                  <p className="text-sm">{n.message}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{n.time}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
