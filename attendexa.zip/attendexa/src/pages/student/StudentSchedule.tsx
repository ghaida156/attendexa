import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SIS_COURSES, getCoursesForStudent } from "@/lib/sis-data";

// Build schedule from SIS data for logged-in student
const studentCourses = getCoursesForStudent("STU-2024-001");

type ScheduleDay = { day: string; courses: { time: string; code: string; name: string; room: string }[] };

function buildSchedule(): ScheduleDay[] {
  const dayMap = new Map<string, { time: string; code: string; name: string; room: string }[]>();
  const dayOrder = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];

  for (const course of studentCourses) {
    for (const slot of course.schedule) {
      const entry = {
        time: `${slot.startTime}–${slot.endTime}`,
        code: course.code,
        name: course.name,
        room: slot.room,
      };
      if (!dayMap.has(slot.day)) dayMap.set(slot.day, []);
      dayMap.get(slot.day)!.push(entry);
    }
  }

  return dayOrder
    .filter((d) => dayMap.has(d))
    .map((d) => ({ day: d, courses: dayMap.get(d)! }));
}

const schedule = buildSchedule();

export default function StudentSchedule() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold">Weekly Schedule</h2>
        <p className="text-muted-foreground">
          <Badge variant="outline" className="mr-2 text-xs">SIS Synced</Badge>
          Spring 2024 · {studentCourses.length} courses enrolled
        </p>
      </div>

      <div className="space-y-4">
        {schedule.map((day) => (
          <Card key={day.day}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{day.day}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {day.courses.map((c, i) => (
                <div key={i} className="flex items-center gap-4 rounded-lg bg-secondary/50 px-4 py-3">
                  <span className="text-sm font-mono font-medium text-muted-foreground w-24">{c.time}</span>
                  <Badge variant="outline">{c.code}</Badge>
                  <span className="text-sm font-medium flex-1">{c.name}</span>
                  <span className="text-xs text-muted-foreground">{c.room}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
